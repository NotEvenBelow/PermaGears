package permagears.permagears.client;

import net.fabricmc.api.ClientModInitializer;

public class PermagearsClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
    }
}
